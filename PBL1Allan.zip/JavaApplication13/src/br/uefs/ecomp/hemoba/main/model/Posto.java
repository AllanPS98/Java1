package br.uefs.ecomp.hemoba.main.model;
// classe responsável pelos atributos, comportamentos e estado de posto
public class Posto {
    private int numPosto;
    private String endereco, telefone, responsavelPosto;
    private static int numPost;
    // apenas um construtor
    public Posto(String ender, String tel, String resp) {
        numPost++;
        this.numPosto = numPost;
        this.endereco = ender;
        this.telefone = tel;
        this.responsavelPosto = resp;
    }
    // métodos acessores e modificadores
    public int getNumPosto() {
        return numPosto;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEnder(String ender) {
        this.endereco = ender;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String tel) {
        this.telefone = tel;
    }

    public String getResponsavelPosto() {
        return responsavelPosto;
    }

    public void setResponsavelPosto(String resp) {
        this.responsavelPosto = resp;
    }
    
}
