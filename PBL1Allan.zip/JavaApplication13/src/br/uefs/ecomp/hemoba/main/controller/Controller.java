package br.uefs.ecomp.hemoba.main.controller;
import br.uefs.ecomp.hemoba.main.model.Doador;
import br.uefs.ecomp.hemoba.main.model.Doacao; 
import br.uefs.ecomp.hemoba.main.model.Posto;
import br.uefs.ecomp.hemoba.main.util.Iterador;
import br.uefs.ecomp.hemoba.main.util.Lista;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Controller {
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    Lista listadoador = new Lista();
    Lista listaposto = new Lista();
    Lista listadoacao = new Lista();
    public Controller() {

    }
    // o método retorna true se o cadastro foi realmente realizado
    public boolean cadastrarDoador(String nome, String endereco, String responsavelDoador, String documento, String telefone, int dianasc, int mesnasc, int anonasc,  float peso) {
        Doador doador = new Doador(nome, endereco, responsavelDoador, documento, telefone, dianasc, mesnasc, anonasc, peso);
        int tam1 = listadoador.obterTamanho();
        listadoador.inserirFinal(doador);
        int tam2 = listadoador.obterTamanho();
        return tam1==(tam2-1);
    }
    // usa o método recuperar da classe lista para devolver um doador para a view
    public Doador obterDoador(Integer matricula) {
        return (Doador) listadoador.recuperar(matricula);
    }
    // o método retorna true se o cadastro foi realmente realizado
    public boolean cadastrarPosto(String endereco, String telefone , String responsavelPosto) {
        Posto posto = new Posto(endereco, telefone , responsavelPosto);
        int tam1 = listaposto.obterTamanho();
        listaposto.inserirFinal(posto);
        int tam2 = listaposto.obterTamanho();
        return tam1==(tam2-1);
    }
    // usa o método recuperar da classe lista para devolver um posto para a view
    public Posto obterPosto(Integer numeroPosto) {
        return (Posto) listaposto.recuperar(numeroPosto);
    }
    // método para cadastrar doação verifica antes do cadastro se eu já tenho o doador e o posto para assim poder cadastrar uma doação
    // mudei o retorno para int, pois diferente de posto e doador, eu exibo uma mensagem de acordo com o valor adquirido
    // valor esse manipulado pela "variável" cont
    public int cadastrarDoacao(Date dataDoacao, int hora, int matricula, int numeroPosto){
        Doacao doacao = new Doacao(dataDoacao, hora, matricula, numeroPosto);
        Iterador itr = listadoador.iterador();
        int cont = 0;
        while(itr.temProximo()){
            Doador d = (Doador) itr.obterProximo();
            if(d.getMatricula() == matricula){
                cont++;
            }
        }
        Iterador itr2 = listaposto.iterador();
        while(itr2.temProximo()){
            Posto p = (Posto) itr2.obterProximo();
            if(p.getNumPosto()== numeroPosto){
                cont++;
            }
        }
        Iterador itr3 = listadoacao.iterador();
        while(itr3.temProximo()){
            Doacao dc = (Doacao) itr3.obterProximo();
            if(dc.getHora()== hora && dc.getDia().compareTo(dataDoacao)==0 && numeroPosto == dc.getNumPosto()){
                cont=3;
            }
        }
        if(cont==2){
            int index = verificaInserir(doacao);
            listadoacao.inserirOrdenado(index, doacao);
        }
        return cont; 
    }
    
    public Iterador listarPostos() {
        return listaposto.iterador();
    }
    public Iterador listarDoadores() {
        return listadoador.iterador();
    }
    public Iterador listarDoacoesDia() {
        return listadoacao.iterador();
    }
    public Iterador listarDoacoesRealizadas(){
        return listadoacao.iterador();
    }
    public Iterador listarDoacoesNaoRealizadas(){
        return listadoacao.iterador();
    }
    // usa um método da classe lista para excluir uma determinada doação
    public void excluirDoacao(int mat, Date data) {
        if(listadoacao.estaVazia()){
        }else{
            int index = verificaRemover(mat, data);
            listadoacao.remover(index);
        }
    }
    // método usado para verificar se o doador precisa ou não de um responsável
    public int verificaResp(int year, int month, int day, int atualD, int atualM, int atualA) throws IOException{
        int resultAno = atualA - year;
        int resultMes = atualM - month;
        int resultDia = atualD - day;
        if(resultAno < 16 || resultAno > 69){
            return 2;
        }
        if(resultAno > 18){
            return 0;
        }else if(resultAno == 18){
            if(resultMes < 0){
                return 1;
            }else if(resultMes > 0){
                return 0;
            }else if(resultDia < 0){
                return 1;
            }
        }return 1;
    }
    public int verificaInserir(Doacao d){ // verifica o indice que deve ser inserida a doação
        int index = 0;
        Iterador itr = listadoacao.iterador();
        Doacao dc;
        while(itr.temProximo()){
            dc = (Doacao) itr.obterProximo();
            if(dc.getHora()<d.getHora()){
                index++;
            }
        }
        return index;
    }
    public int verificaRemover(int mat, Date data){ // verifica o índice que deve ser removida a doação
        int index = 1;
        Iterador itr = listadoacao.iterador();
        Doacao dc;
        while(itr.temProximo()){
            dc = (Doacao) itr.obterProximo();
            if(dc.getDia().compareTo(data)==0 && dc.getMat() == mat){
                return index;
            }
            index++;
        }
        return index;
    }
}
