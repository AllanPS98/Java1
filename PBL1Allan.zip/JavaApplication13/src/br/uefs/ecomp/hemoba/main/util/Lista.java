package br.uefs.ecomp.hemoba.main.util;

public class Lista implements ILista { // a célula contém um ponteiro pro primeiro e outro pro último para auxiliar em alguns métodos
    private Celula primeiro;
    private Celula ultimo;
    private int total;
    private class Celula { // celula da lista que contém os dados e um ponteiro para a próxima célula
        private Object dados;
        private Celula prox;

        public Celula(Object o) {
            this.dados = o;
        }

        public Object getDados() {
            return dados;
        }

        public void setDados(Object o) {
            this.dados = o;
        }

        public Celula getProx() {
            return prox;
        }

        public void setProx(Celula prox) {
            this.prox = prox;
        }

    }
    // informa true ou false, dependendo da situação da lista, vazia ou não
    @Override
    public boolean estaVazia() {
        return this.total==0;
    }
    // informa o tamanho da lista
    @Override
    public int obterTamanho(){
        return this.total;
    }
    // insere no início com ajuda dos ponteiros pro início e pro fim da lista
    @Override
    public void inserirInicio(Object o) {
        Celula novo = new Celula(o);
        novo.setProx(this.primeiro);
        this.primeiro = novo;
        if(this.total==0){
            this.ultimo = this.primeiro;
        }
        this.total++;   
    }
    // insere no final com ajuda do ponteiro pro fim da lista
    @Override
    public void inserirFinal(Object o) {
        if(this.total==0){
            this.inserirInicio(o);
        }else{
            Celula novo = new Celula(o);
            this.ultimo.setProx(novo);
            this.ultimo = novo;
            this.total++;
        }
    }
    // insere ordenadamente a partir de hora... esse método só é usado em doação
    // a lista é genérica mas contém dois métodos que são usados especificamente para doação
    public void inserirOrdenado(int index, Object o){
        if(index == 0){
            inserirInicio(o);
            return;
        }
        Celula aux1 = this.primeiro;
        Celula aux2 = null;
        if(index == this.total){
            inserirFinal(o);
        }
        else {            
            while(index>0){
                aux2 = aux1;
                aux1 = aux1.getProx();
                index--;
            }
            Celula nova = new Celula(o);
            nova.setProx(aux1);
            aux2.setProx(nova);
            this.total++;
        }
    }
    // remove o primeiro elemento da lista e atualiza-o
    @Override
    public Object removerInicio() {
        if(this.total==0){
            return null;
        }else {
            this.primeiro = this.primeiro.getProx();
            this.total--;
        }
        if(this.total==0){
            this.ultimo = null; 
        }
        return this.primeiro;
    }
    // remove o último elemento da lista e atualiza-o 
    @Override
    public Object removerFinal() { 
        Celula aux = this.ultimo;
        Celula auxi = null;
        if(this.total==0){
            return auxi;
        }else if (this.total==1){
            removerInicio();
        }else{
            auxi = this.primeiro;
            while(auxi.getProx()!=aux){
                auxi = auxi.getProx(); 
            }
            auxi.setProx(null);
            this.ultimo = auxi;
        }
        return aux;
    }
    // remove uma doação... tanto no início quanto no fim e se for necessário, no meio.
    public void remover(int index) { 
        Celula aux = this.primeiro;
        Celula auxi = null;
        
        if(this.obterTamanho()==0){
      
        }else if(index==1){
            removerInicio();
        }else if(index==this.obterTamanho()){
            removerFinal();
        }
        else if(index<this.obterTamanho()){
            while(aux!=null){
                if(index==1){
                    auxi.setProx(aux.getProx());
                    aux.setProx(null);
                    this.total--;
                    return;
                }
                auxi = aux;
                aux = aux.getProx();
                index--;
            }
        }
    }
    // pega determinado objeto apartir de um índice
    @Override
    public Object recuperar(int index) {
        if(this.estaVazia())
            return null;
        Iterador i = this.iterador();        
        Object ret = i.obterProximo();
        while(i.temProximo()){            
            if(index == 1){
                return ret;
            }
            ret = i.obterProximo();
            index--;
        }
        return ret;
    }
    // iterador feito para poder percorrer a lista
    private class Iterator implements Iterador{
        private Celula no;
        
        public Iterator() {
            this.no = primeiro;
        }
        @Override
        public boolean temProximo(){
            return no != null;
        }
        @Override
        public Object obterProximo(){
            if(temProximo()){ // talvez esse if seja desnecessário, mas é melhor prevenir do que remediar 
                Celula aux = no;
                no = no.getProx();
                return aux.getDados();
            }
            return null;
        }
    }
    // método que retorna o iterador
    public Iterator iterador(){
        return new Iterator();
    }    
      
}
