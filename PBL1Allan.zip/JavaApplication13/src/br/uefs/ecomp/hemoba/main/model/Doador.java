package br.uefs.ecomp.hemoba.main.model;
// classe responsável pelos atributos, comportamentos e estado de doador
public class Doador  {
    private String nome, ender, resp, doc, tel;
    private int dianasc, mesnasc, anonasc;
    private float peso;
    private int matricula;
    private static int mat;
    // dois construtores, um com parâmetros e um default
    public Doador(String nome, String ender, String resp, String doc, String tel, int dianasc, int mesnasc, int anonasc, float peso) {
        this.nome = nome;
        this.ender = ender;
        this.resp = resp;
        this.doc = doc;
        this.tel = tel;
        this.dianasc = dianasc;
        this.mesnasc = mesnasc;
        this.anonasc = anonasc;
        this.peso = peso;
        mat++;
        this.matricula = mat;
    }
    public Doador() {
        
    }
    // métodos acessores e modificadores
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return ender;
    }

    public int getDianasc() {
        return dianasc;
    }

    public int getMesnasc() {
        return mesnasc;
    }

    public int getAnonasc() {
        return anonasc;
    }

    public String getResp() {
        return resp;
    }

    public String getDoc() {
        return doc;
    }

    public String getTel() {
        return tel;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }   

    
    
}
