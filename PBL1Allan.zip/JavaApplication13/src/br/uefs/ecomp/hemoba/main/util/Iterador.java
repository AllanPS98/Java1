package br.uefs.ecomp.hemoba.main.util;

public interface Iterador {
	
	public boolean temProximo();

	public Object obterProximo();

}
