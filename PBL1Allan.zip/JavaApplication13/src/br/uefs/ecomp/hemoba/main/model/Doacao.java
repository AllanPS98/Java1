package br.uefs.ecomp.hemoba.main.model;
import java.util.Date;
// classe responsável pelos atributos, comportamentos e estado de doação
public class Doacao{
    private Date dia; 
    int hora;
    private int mat;
    private int numPosto;
    private boolean status;
    // dois construtores, um com parâmetros e um default
    public Doacao(Date dia, int hora, int mat, int numPosto) {
        this.dia = dia;
        this.hora = hora;
        this.mat = mat;
        this.numPosto = numPosto;
    }

    public Doacao() {
    }
    // métodos acessores e modificadores
    public Date getDia() {
        return dia;
    }

    public void setDia(Date dia) {
        this.dia = dia;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public int getMat() {
        return mat;
    }

    public int getNumPosto() {
        return numPosto;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }    
}
