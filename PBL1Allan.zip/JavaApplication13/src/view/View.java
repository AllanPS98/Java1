package view;
import br.uefs.ecomp.hemoba.main.controller.Controller;
import br.uefs.ecomp.hemoba.main.model.Doacao;
import br.uefs.ecomp.hemoba.main.model.Doador;
import br.uefs.ecomp.hemoba.main.model.Posto;
import br.uefs.ecomp.hemoba.main.util.Iterador;
import java.io.IOException;
import java.text.ParseException; // importado para ajudar na formatação da hora
import java.text.SimpleDateFormat; // importado para ajudar na formatação da hora
import java.util.Date;
public class View { // Classe View responsável pela entrada e pela saída de dados
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); // O SimpleDateFormat é usado pra formatar a data tanto na hora da leitura quanto na hora do print
    public static void main(String[] args) throws IOException, ParseException {
        Controller faca = new Controller();
        View method  = new View();
        int opcao=1, menu=1;
        while(opcao > 0 && opcao < 14 || menu == 1){
            System.out.println("---------------------------------");
            System.out.println("---------------Menu--------------");
            System.out.println("{1}- Cadastrar doador          {}");
            System.out.println("{2}- Cadastrar posto           {}");
            System.out.println("{3}- Cadastrar doacao          {}");
            System.out.println("{4}- Atualizar doacao          {}");
            System.out.println("{5}- Consultar doador          {}");
            System.out.println("{6}- Consultar posto           {}");
            System.out.println("{7}- Excluir doacao            {}");
            System.out.println("{8}- Listar doadores           {}");
            System.out.println("{9}- Listar postos             {}");
            System.out.println("{10}- Listar doacoes do dia    {}");
            System.out.println("{11}- Listar doacoes feitas    {}");
            System.out.println("{12}- Listar doacoes pendentes {}");
            System.out.println("{13}- Sair                     {}");
            System.out.println("---------------------------------");
            System.out.println("---------------------------------");
            opcao = Console.readInt();
            switch(opcao){
                case 1:
                    method.cadastroDoador(faca);
                    break;
                case 2:
                    method.cadastroPosto(faca);
                    break;
                case 3:
                    method.cadastroDoacao(faca);
                    break;
                case 4: 
                    method.atualizaDoacao(faca);
                    break;
                case 5:
                    method.consultaDoador(faca);
                    break;
                case 6:
                    method.consultaPosto(faca);
                    break;
                case 7:
                    method.excluirDoacao(faca);
                    break;
                case 8:
                    method.listaDoador(faca);
                    break;
                case 9:
                    method.listaPosto(faca);
                    break;
                case 10: 
                    method.listaDoacaoDia(faca);
                    break;
                case 11:
                    method.listaDoacaoRealizada(faca);
                    break;
                case 12:
                    method.listaDoacaoNaoRealizada(faca);
                    break;
                case 13:
                    menu = 0;
                    opcao = 0;
                    break;
                default:
                    System.out.println("Insira corretamente!");
                    break;
            }
        }
    }
    private void cadastroDoador(Controller faca) throws IOException{ // método para cadastro de um doador
        int ano, mes, dia, atualyear, atualmonth, atualday;
        float peso;
        String nome , endereco, telefone, responsavelDoador, documento;
        System.out.println("Insira o nome: ");
        nome = Console.readString();
        System.out.println("Insira o endereço: ");
        endereco = Console.readString();
        System.out.println("Insira o telefone: ");
        telefone = Console.readString();
        System.out.println("Insira o peso: ");
        peso = Console.readFloat();
        if(peso<=50){
            System.out.println("Inapto à doar!");
            return;
        }
        System.out.println("Insira o numero do seu documento: ");
        documento = Console.readString();
        System.out.println("Data de nascimento");
        System.out.println("Dia: ");
        dia = Console.readInt();
        System.out.println("Mês: ");
        mes = Console.readInt();
        System.out.println("Ano: ");
        ano = Console.readInt();
        System.out.println("Data de hoje");
        System.out.println("Dia: ");
        atualday = Console.readInt();
        System.out.println("Mês: ");
        atualmonth = Console.readInt();
        System.out.println("Ano: ");
        atualyear = Console.readInt();
        int calculaIdade;
        calculaIdade = faca.verificaResp(ano, mes, dia, atualday, atualmonth, atualyear);
        if(calculaIdade==1){
            System.out.println("Insira o nome do responsavel: ");
            responsavelDoador = Console.readString();
        }else if(calculaIdade==0) {
            responsavelDoador = "De maior";
        }else{
            System.out.println("Inapto à doar!");
            return;
        }
        boolean resultDoador = faca.cadastrarDoador(nome, endereco, responsavelDoador, documento, telefone, dia, mes, ano, peso);
        if(resultDoador){
            System.out.println("Doador inserido com sucesso!");
        }else{
            System.out.println("Tente novamente!");
        }
    }
    private void cadastroPosto(Controller faca) throws IOException{ // método para cadastro de um posto
        System.out.println("Insira o endereço do posto: ");
        String enderecoPosto = Console.readString();
        System.out.println("Insira o telefone do posto: ");
        String telefonePosto = Console.readString();
        System.out.println("Insira o nome do responsável pelo posto: ");
        String responsavelPosto = Console.readString();
        boolean resultPosto = faca.cadastrarPosto(enderecoPosto, telefonePosto, responsavelPosto);
        if(resultPosto){
            System.out.println("Posto inserido com sucesso!");
        }else{
            System.out.println("Tente novamente!");
        }
    }
    private void cadastroDoacao(Controller faca) throws IOException, ParseException{ // método para cadastro de uma doação
        System.out.println("Insira o dia da doação: Ex: DIA/MÊS/ANO");
        String d = Console.readString();
        Date dataDoacao = formato.parse(d);
        System.out.println("Insira a hora da doacao: ");
        int hora = Console.readInt();
        System.out.println("Insira o numero do posto: ");
        int numPosto = Console.readInt();
        System.out.println("Insira a matricula do doador: ");
        int matricula = Console.readInt();
        System.out.println("Insira o peso: ");
        float peso = Console.readFloat();
        if(peso<=50f){
            System.out.println("Inapto à doar!");
            return;
        }
        Iterador it = faca.listarDoacoesDia();
        Doacao dc;
        int cont = 0;
        while(it.temProximo()){ // Verifica a partir da matrícula se o doador que vai realizar uma doação já fez alguma doação nesse dia
            dc = (Doacao) it.obterProximo();
            if(dc.getMat() == matricula && dataDoacao.compareTo(dc.getDia())==0){
                cont++;
            }
        }
        if(cont==0){
            int teste = faca.cadastrarDoacao(dataDoacao, hora, matricula, numPosto);
            switch (teste) {
                case 2:
                    System.out.println("Doação inserida com sucesso!");
                    break;
                case 1:
                    System.out.println("O posto ou o doador não foi encontrado.");
                    break;
                case 3:
                    System.out.println("Já tem uma doação cadastrada para essa hora.");
                    break;
                default:
                    System.out.println("ERRO!");
                    break;
            }
        }
        else{
            System.out.println("Por questões de saúde, o doador só poderá realizar uma doação por dia.");
        }
    }
    private void atualizaDoacao(Controller faca) throws IOException, ParseException{ // atualiza o status da doação para realizada ou não realizada
        Iterador it = faca.listarDoacoesDia();
        Doacao dc;
        int status;
        System.out.println("Insira o dia da doação: Ex: DIA/MÊS/ANO");
        String d = Console.readString();
        Date data = formato.parse(d);
        System.out.println("Insira a hora da doacao: ");
        int hora = Console.readInt();
        System.out.println("Insira o numero do posto: ");
        int numP = Console.readInt();
        System.out.println("Insira a matricula do doador: ");
        int mat = Console.readInt();
        while(it.temProximo()){
            dc = (Doacao) it.obterProximo();
            if((dc.getDia().compareTo(data)==0) && dc.getHora() == hora && dc.getMat() == mat && dc.getNumPosto() == numP){
                System.out.println("Digite 1 para confirmar a doação ou 2 para negar a doação");
                status = Console.readInt();
                if(status==1){
                    dc.setStatus(true);
                }else if(status==2){
                    dc.setStatus(false);
                }
            }
        }
        
    }
    private void consultaDoador(Controller faca) throws IOException{ // busca um doador a partir da matrícula
        Doador d;
        System.out.println("Insira o numero de matricula do doador: ");
        int matricula = Console.readInt();
        d = faca.obterDoador(matricula);
        System.out.println("------------------------------------");
        System.out.println("Nome: " + d.getNome());
        System.out.println("Endereco: " + d.getEndereco());
        System.out.println("Telefone: " + d.getTel());
        System.out.println("Data de nascimento: " + d.getDianasc() + "/" + d.getMesnasc() + "/" + d.getAnonasc());
        System.out.println("Peso " + d.getPeso());
        System.out.println("Nome do responsável: " + d.getResp());
        System.out.println("Número de matrícula: " + d.getMatricula());
        System.out.println("------------------------------------");
    }
    private void consultaPosto(Controller faca) throws IOException{ // busca um posto a partir do numero do posto
        Posto p;
        System.out.println("Insira o numero do posto: ");
        int numPosto = Console.readInt();
        p = faca.obterPosto(numPosto);
        System.out.println("------------------------------------");
        System.out.println("Endereco: " + p.getEndereco());
        System.out.println("Telefone: " + p.getTelefone());
        System.out.println("Número do posto: " + p.getNumPosto());
        System.out.println("Responsavel " + p.getResponsavelPosto());
        System.out.println("------------------------------------");
    }
    private void excluirDoacao(Controller faca) throws IOException, ParseException{ // exclui uma doação a partir de data e matrícula do doador
        System.out.println("Insira o dia da doação: Ex: DIA/MÊS/ANO");
        String d = Console.readString();
        Date data = formato.parse(d);
        System.out.println("Insira a matricula do doador: ");
        int mat = Console.readInt();
        faca.excluirDoacao(mat, data);
        System.out.println("");
    }
    private void listaDoador(Controller faca){ // lista todos os doadores cadastrados a partir de um iterador
        Iterador i1;
        i1 =  faca.listarDoadores();
        Doador d1;
        while(i1.temProximo()){
            d1 = (Doador) i1.obterProximo();
            System.out.println("------------------------------------");
            System.out.println("Nome: " + d1.getNome());
            System.out.println("Endereco: " + d1.getEndereco());
            System.out.println("Telefone: " + d1.getTel());
            System.out.println("Peso " + d1.getPeso());
            System.out.println("Nome do responsável: " + d1.getResp());
            System.out.println("------------------------------------");
        }
    }
    private void listaPosto(Controller faca){ // lista todos os postos cadastrados a partir de um iterador
        Iterador i2;
        i2 = faca.listarPostos();
        Posto p1;
        while(i2.temProximo()){
            p1  = (Posto) i2.obterProximo();
            System.out.println("------------------------------------");
            System.out.println("Endereco: " + p1.getEndereco());
            System.out.println("Telefone: " + p1.getTelefone());
            System.out.println("Número do posto: " + p1.getNumPosto());
            System.out.println("Responsavel " + p1.getResponsavelPosto());
            System.out.println("------------------------------------");
        }
    }
    private void listaDoacaoDia(Controller faca) throws IOException, ParseException{ // lista as doações do dia desejado
        Iterador i3;
        System.out.println("Insira a data da doação: Ex DIA/MES/ANO");
        String d = Console.readString();
        Date dataDoacao = formato.parse(d);
        i3 = faca.listarDoacoesDia();
        Doacao dc1;
        while(i3.temProximo()){
            dc1 = (Doacao) i3.obterProximo();
            if(dc1.getDia().compareTo(dataDoacao)==0){
                System.out.println("------------------------------------");
                System.out.println("Data da doação: " + formato.format(dc1.getDia()));
                System.out.println("Hora da doação: " + dc1.getHora());
                System.out.println("Número do posto: " + dc1.getNumPosto());
                System.out.println("Matrícula do doador: " + dc1.getMat());
                if(dc1.getStatus()){
                    System.out.println("Status da doação: Realizada");
                }else{
                    System.out.println("Status da doação: Não Realizada");
                }
                System.out.println("------------------------------------");
            }
        }
    }
    private void listaDoacaoRealizada(Controller faca){ // lista as doações realizadas de qualquer dia
        Iterador i4 = faca.listarDoacoesRealizadas();
        Doacao dc2;
        while(i4.temProximo()){
            dc2 = (Doacao) i4.obterProximo();
            if(dc2.getStatus()==true){
                System.out.println("------------------------------------");
                System.out.println("Data da doação: " + formato.format(dc2.getDia()));
                System.out.println("Hora da doação: " + dc2.getHora());
                System.out.println("Número do posto: " + dc2.getNumPosto());
                System.out.println("Matrícula do doador: " + dc2.getMat());
                System.out.println("Status da doação: Realizada");
                System.out.println("------------------------------------");
            }
            
        }
    }
    private void listaDoacaoNaoRealizada(Controller faca){ // lista as doações não realizadas de qualquer dia
        Iterador i5 = faca.listarDoacoesNaoRealizadas();
        Doacao dc3;
        while(i5.temProximo()){
            dc3 = (Doacao) i5.obterProximo();
            if(dc3.getStatus()==false){
                System.out.println("------------------------------------");
                System.out.println("Data da doação: " + formato.format(dc3.getDia()));
                System.out.println("Hora da doação: " + dc3.getHora());
                System.out.println("Número do posto: " + dc3.getNumPosto());
                System.out.println("Matrícula do doador: " + dc3.getMat());
                System.out.println("Status da doação: Não Realizada");
                System.out.println("------------------------------------");
            }
            
        }
    }
}